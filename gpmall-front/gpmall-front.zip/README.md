# 部署说明

1. 安装nodejs环境
2. 安装python2.7环境
3. 进入到gpmall-front目录，执行npm install
4. 上述步骤成功后，执行 npm run dev 启动项目